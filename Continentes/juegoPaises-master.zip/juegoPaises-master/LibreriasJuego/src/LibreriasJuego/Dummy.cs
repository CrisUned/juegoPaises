﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibreriasJuego.src.LibreriasJuego
{
    class Dummy
    {

        public static void Main() { }

    }
}
