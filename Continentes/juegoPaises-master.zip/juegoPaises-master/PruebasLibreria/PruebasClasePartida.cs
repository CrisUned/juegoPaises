using LibreriasJuego;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace PruebasLibreria
{
    [TestClass]
    public class PruebasClasePartida
    {
        [TestMethod]
        public void TestCrearPartida()
        {
            //Partida p = new Partida();
        }
    }
}
